

//
//  SwiftUIView.swift
//  TermProjectDraft
//
//  Created by Will Sheffield on 12/5/21.
//

import UIKit
import SwiftUI
import EventKit

class CalendarPage: UIHostingController<MyCalendarUIView> {
    override func viewDidLoad() {
        super.viewDidLoad()
        //setup
        
        // Load in background theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
    }
    
    required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder, rootView: MyCalendarUIView())
    }
}

struct MyCalendarUIView: View {
    @State private var es = EKEventStore()
    @State private var date = Date()
    @State private var needAccess = false
    @State private var calender: EKCalendar?
    @State private var added = false
    
    func addevent(_ frequency:String) -> String?{
        var problem:String?
        var eventFrequency: EKRecurrenceRule
        
        switch frequency {
        case "Week":
            eventFrequency = EKRecurrenceRule(
                recurrenceWith: .weekly,
                interval: 1,
                end: EKRecurrenceEnd(occurrenceCount: 52))
        case "Weekday":
            eventFrequency = EKRecurrenceRule(
                recurrenceWith: .weekly,
                interval: 1,
                daysOfTheWeek:
                    [EKRecurrenceDayOfWeek(EKWeekday.monday),
                     EKRecurrenceDayOfWeek(EKWeekday.tuesday),
                     EKRecurrenceDayOfWeek(EKWeekday.wednesday),
                     EKRecurrenceDayOfWeek(EKWeekday.thursday),
                     EKRecurrenceDayOfWeek(EKWeekday.friday)],
                daysOfTheMonth: nil,
                monthsOfTheYear: nil,
                weeksOfTheYear: nil,
                daysOfTheYear: nil,
                setPositions: nil,
                end: EKRecurrenceEnd(occurrenceCount: 260))
        default:
            eventFrequency = EKRecurrenceRule(
                recurrenceWith: .daily,
                interval: 1,
                end: EKRecurrenceEnd(occurrenceCount: 365))
        }

        //getCalendar()

        if EKEventStore.authorizationStatus(for: .event) != EKAuthorizationStatus.authorized {
            es.requestAccess(to: .event, completion: { (granted, error) in
                if let e = error{
                    print(e)
                    needAccess = true
                } else if (granted == true){
                    let event = EKEvent(eventStore: es)
                    event.title = "UToilet Visit"
                    event.startDate = date
                    event.endDate = date.addingTimeInterval(60*10)
                    event.addRecurrenceRule(eventFrequency)
                    event.calendar = es.defaultCalendarForNewEvents
                    
                    do {
                        try es.save(event, span: .thisEvent)
                        added = true
                    } catch {
                        print("Unexpected: \(error)")
                    }
                } else {
                    needAccess = true
                    problem = "Please provide access to the calendar to use this feature"
                }
            })
        } else {
            let event = EKEvent(eventStore: es)
            event.title = "UToilet Visit"
            event.startDate = date
            event.endDate = date.addingTimeInterval(60*10)
            event.addRecurrenceRule(eventFrequency)
            event.calendar = es.defaultCalendarForNewEvents
            
            do {
                try es.save(event, span: .thisEvent)
                added = true
            } catch {
                print("Unexpected: \(error)")
            }
        }
        return problem
    }
    
    var body: some View {
        VStack() {
            Spacer()
            Text("Schedule Your Visits")
            Spacer()
            Text("Schedule a new time to help plan your bathroom visits")
            HStack() {
                DatePicker(
                    "at",
                    selection: $date,
                    displayedComponents: [.hourAndMinute])
                    .datePickerStyle(.compact)
                    .frame(width: 130)
                Text("every")
            }
            HStack() {
                Button(action: {addevent("Day")}, label: {Text("Day")})

                Button(action: {addevent("Week")}, label: {Text("Week")})

                Button(action: {addevent("Weekday")}, label: {Text("Weekday")})
            }
            Spacer()
        }
        .alert(isPresented: $needAccess) {
            Alert(title: Text("Calendar Access"),
                  message: Text("Please provide access to the calendar to use this feature"),
                  dismissButton: .default(Text("OK"), action: {needAccess = false}))
        }
        .alert(isPresented: $added) {
            Alert(title: Text("Visit Added"),
                  message: Text("Your visit has been added"),
                  dismissButton: .default(Text("OK"), action: {added = false}))
        }
    }
}

struct MyCalendarUIView_Preview: PreviewProvider {
    static var previews: some View {
        MyCalendarUIView()
    }
}

