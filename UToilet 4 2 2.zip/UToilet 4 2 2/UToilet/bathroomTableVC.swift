
//
//  bathroomTableVC.swift
//  SheldenNan-PartialUI
//
//  Created by Nan Shelden on 11/29/21.
//

import UIKit
import MapKit
import Firebase
import FirebaseDatabase

class Building {
    var title: String!
    var coordinates: CLLocation!
    var id: String!
    
}

class Review: Equatable {
    var title: String!
    var text: String!
    var rating: Double!
    var author: String!
    var id: String!
    
    
    static func == (lhs: Review, rhs: Review) -> Bool {
        return lhs.id == rhs.id
    }
}

class Bathroom: Equatable {
    
    var building: Building!
    var room: String!
    var reviews: [Review] = []
    var gender: String!
    
    
    func show() -> String {
        return "\(building.title!) | Room \(room!)"
    }
    
    static func == (lhs: Bathroom, rhs: Bathroom) -> Bool {
        return lhs.show() == rhs.show()
    }
    
    func getRating() -> Double {
        var ratings: [Double] = []
        for review in self.reviews {
            ratings.append(review.rating!)
        }
        return Double(ratings.reduce(0, +)) / Double(ratings.count)
    }
    
}

class bathroomTableVC: UIViewController,
                       UITableViewDataSource,
                       UITableViewDelegate,UISearchBarDelegate {
    
    //data holders
    var bathrooms: [Bathroom] = []
    var buildings: [Building] = []
    
    var mapView = MKMapView()
    

    @IBOutlet weak var searchBar: UISearchBar!
    
    var filteredBathrooms: [Bathroom] = []
    

    //identifiers
    var textCellIdentifier = "TextCell"
    var bathroomSegueIdentifier = "BathroomSegue"
    
    //view objects
    @IBOutlet var tableView: UITableView!
    
    var data: DatabaseReference! = Database.database().reference()
    var refLoc: DatabaseReference!
    var refRev: DatabaseReference!
    
    // ---------------------------------------------------------------
    
    let dataqueue = DispatchQueue(label: "data", qos: .default)
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        
        // Load in background theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        
        
        //locations
        refLoc = data.child("locations")
        
        //observing the data changes
        refLoc.observe(DataEventType.value, with: { (snapshot) in
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //clearing the list
                self.buildings.removeAll()
                
                //iterating through all the values
                for buildings in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let buildingObj = buildings.value as? [String: AnyObject]
                    let buildingId = buildings.key
                    let buildingName  = buildingObj?["display"]
                    let buildingLat = buildingObj?["latitude"]
                    let buildingLon = buildingObj?["longitude"]
                    let buildingBathrooms = buildingObj?["bathrooms"] as! NSDictionary
                    
                    //creating building object with model and fetched values
                    let building = Building()
                    building.title = buildingName as! String?
                    building.coordinates = CLLocation(latitude: buildingLat as! Double, longitude: buildingLon as! Double)
                    building.id = buildingId
                    
                    //appending it to list
                    self.buildings.append(building)
    
                    for room in buildingBathrooms {
                        let bathroom = Bathroom()
                        bathroom.building = building as Building?
                        bathroom.room = room.key as! String?
                        bathroom.reviews = []
                        self.bathrooms.append(bathroom)
                    }
                }
                self.filteredBathrooms = self.bathrooms
            }
        })
        
        //reviews
        refRev = data.child("reviews")
        
        //observing the data changes
        refRev.observeSingleEvent(of: DataEventType.value, with: { (snapshot) in
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //iterating through all the values
                for reviews in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let reviewObj = reviews.value as? [String: AnyObject]
                    let reviewId = reviews.key
                    let reviewTitle  = reviewObj?["title"]
                    let reviewText = reviewObj?["text"]
                    let reviewRating = reviewObj?["rating"]
                    let reviewAuthor = reviewObj?["author"]
                    let reviewRoom = reviewObj?["room"]
                    let reviewBuilding = reviewObj?["building"]
                    
                    //creating review object with model and fetched values
                    let review = Review()
                    review.title = reviewTitle as! String?
                    review.text = reviewText as! String?
                    review.rating = reviewRating as! Double?
                    review.author = reviewAuthor as! String?
                    review.id = reviewId as String?
                
    
                    for bathroom in self.bathrooms {
                        if bathroom.building.id == reviewBuilding as! String? && bathroom.room == reviewRoom as! String? {
                            bathroom.reviews.append(review)
                            
                        }
                    }
                }
                self.tableView.reloadData()
            }
        })
        
    }

    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        
      return filteredBathrooms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let bathroom: Bathroom

        cell.textLabel?.numberOfLines = 0

        cell.textLabel?.text = "Building: \(filteredBathrooms[indexPath.row].building.title!)\n Room #: \(filteredBathrooms[indexPath.row].room!)\n Rating: \(filteredBathrooms[indexPath.row].getRating())"
      return cell
    }

    
    // segue to building view
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == bathroomSegueIdentifier,
           let destination = segue.destination as? BathroomVC,
           let bathroomIndex = tableView.indexPathForSelectedRow?.row {
            destination.bathroom = filteredBathrooms[bathroomIndex]
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filteredBathrooms = searchText.isEmpty ? bathrooms : bathrooms.filter { (item: Bathroom) -> Bool in
            // If dataItem matches the searchText, return true to include it
            return item.show().range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
        }
        
        tableView.reloadData()
    }

}
