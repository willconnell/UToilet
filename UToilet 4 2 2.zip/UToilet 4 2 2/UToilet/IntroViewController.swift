//
//  IntroViewController.swift
//  UToilet
//
//  Created by William Connell on 12/2/21.
//

import UIKit
import AVFoundation


class IntroViewController: UIViewController {
    
    var player: AVAudioPlayer?
    
    let screenWidth = UIScreen.main.bounds.width
    let screenHeight = UIScreen.main.bounds.height
    
    private let imageView: UIImageView = {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
        imageView.image = UIImage(named: "logo")
        return imageView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(imageView)
        
        // Load in background theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        
        // play audio
        if let player = player, player.isPlaying {
            // stop playback
            
            player.stop()
        } else {
            // set up player, and play
            let urlString = Bundle.main.path(forResource: "toilet-flush-2", ofType: "mp3")
            do {
                try AVAudioSession.sharedInstance().setMode(.default)
                try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
                
                guard let urlString = urlString else {
                    return
                }
                
                player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: urlString))
                
                guard let player = player else {
                    return
                }
                
                player.play()
            } catch {
                print("something went wrong")
            }
        }
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imageView.center = view.center
        
        // execute animation after logo is on screen for 0.1 second
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
            self.animate()
        })
    }
    
    // function that performs animation, then triggers segue upon completion
    private func animate() {
        UIView.animate(withDuration: 0.8, animations: {
            self.imageView.frame = CGRect(x: self.screenWidth / 2 - 300 / 2, y: self.screenHeight + 300 / 2, width: 300, height: 300)
        }, completion: {done in
            if done {
                print("animation complete!")
                self.performSegue(withIdentifier: "showLogin", sender: nil)
            }
        })
    }


}
