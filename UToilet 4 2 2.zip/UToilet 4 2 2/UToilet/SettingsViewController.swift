//
//  SettingsViewController.swift
//  UToilet
//
//  Created by Max Truty on 12/5/21.
//

import UIKit
import AVFoundation
import SwiftTheme

struct myVariables {
    static var switchOn = false
    static var imageString = "toilet"
    static var currentMapIndex = 0
    static var currentSwitchIndex = 1
    static var musicBool = true
    
}

class SettingsViewController: UIViewController {

    @IBOutlet weak var themeSegment: UISegmentedControl!
    @IBOutlet weak var themeLabel: UILabel!
    @IBOutlet weak var settingsLabel: UILabel!
    @IBOutlet weak var mapLabel: UILabel!
    @IBOutlet weak var audioLabel: UILabel!
    @IBOutlet weak var mapSegment: UISegmentedControl!
    @IBOutlet weak var toiletImage: UIImageView!
    @IBOutlet weak var starSegment: UISegmentedControl!
    
            
    var player: AVAudioPlayer?
            
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        settingsLabel.theme_textColor = GlobalPicker.textColor
        themeLabel.theme_textColor = GlobalPicker.textColor
        audioLabel.theme_textColor = GlobalPicker.textColor
        mapLabel.theme_textColor = GlobalPicker.textColor
        
        myVariables.musicBool = false

 
        themeSegment.theme_backgroundColor = GlobalPicker.backgroundColor

        // remember what theme was last chosen
        themeSegment.selectedSegmentIndex = ThemeManager.currentThemeIndex
        
        mapSegment.selectedSegmentIndex = myVariables.currentMapIndex
        
        starSegment.selectedSegmentIndex = myVariables.currentSwitchIndex
        
        
        if myVariables.currentMapIndex == 0 {
            toiletImage.image = UIImage(named: "toilet")
        } else {
            toiletImage.image = UIImage(named: "paper")
        }

    }
    
    @IBAction func segmentChanged(_ sender: Any) {
        switch themeSegment.selectedSegmentIndex {
            case 0:
                MyThemes.switchTo(theme: .red)
            case 1:
                MyThemes.switchTo(theme: .yello)
            
            case 2:
                MyThemes.switchTo(theme: .blue)
            
            default:
                MyThemes.restoreLastTheme()

        }
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        MyThemes.saveLastTheme()
    
    }
    
    @IBAction func startSegmentChanged(_ sender: Any) {
        switch starSegment.selectedSegmentIndex {
        case 0:
            myVariables.switchOn = true
            myVariables.currentSwitchIndex = 0
            
        case 1:
            myVariables.switchOn = false
            myVariables.currentSwitchIndex = 1

        default:
            debugPrint("oh no")

        }
    }
    
    
    @IBAction func mapSegmentChanged(_ sender: Any) {
        switch mapSegment.selectedSegmentIndex {
        case 0:
            myVariables.imageString = "toilet"
            toiletImage.image = UIImage(named: "toilet")
            myVariables.currentMapIndex = 0
            
        case 1:
            myVariables.imageString = "paper"
            toiletImage.image = UIImage(named: "paper")
            myVariables.currentMapIndex = 1

        default:
            if myVariables.currentMapIndex == 0 {
                toiletImage.image = UIImage(named: "toilet")
                myVariables.currentMapIndex = 0
            } else {
                toiletImage.image = UIImage(named: "paper")
                myVariables.currentMapIndex = 1
            }

        }
    }

}


