//
//  GlobalPicker.swift
//  UToilet
//
//  Created by Max Truty on 12/5/21.
//

import Foundation
import SwiftTheme

enum GlobalPicker {
    static let backgroundColor: ThemeColorPicker = ["#FFF", "#F49200", "#56ABE4", "#FFF"]
    static let textColor: ThemeColorPicker = ["#000", "#ECF0F1", "#ECF0F1", "#ECF0F1"]
    
    static let barTextColors = ["#FFF", "#000", "#FFF", "#FFF"]
    static let barTextColor = ThemeColorPicker.pickerWithColors(barTextColors)
    static let barTintColor: ThemeColorPicker = ["#EB4F38", "#F4C600", "#56ABE4", "#01040D"]
}
