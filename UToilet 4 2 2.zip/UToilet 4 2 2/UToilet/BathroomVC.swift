//
//  BathroomVC.swift
//  SheldenNan-PartialUI
//
//  Created by Nan Shelden on 11/16/21.
//

import UIKit

class BathroomVC: UIViewController,
                  UITableViewDataSource,
                  UITableViewDelegate {
    
    
    var bathroom: Bathroom!
    
    var textCellIdentifier = "TextCell"
    var readReviewSegueIdentifier = "readReviewSegue"
    var writeSegueIdentifier = "writeReviewSegue"
    
    
    @IBOutlet weak var bathroomLabel: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        bathroomLabel.text = bathroom.show()
        
        // Load in background theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        
        tableView.reloadData()
        
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bathroom.reviews.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let review: Review
        review = bathroom.reviews[indexPath.row]
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.text = "\(review.title!)\n Rating: \(review.rating!)/5 \n \(review.text!)"
      return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == readReviewSegueIdentifier,
           let destination = segue.destination as? reviewReadVC,
           let reviewIndex = tableView.indexPathForSelectedRow?.row {
            destination.review = bathroom.reviews[reviewIndex]
            destination.bathroom = self.bathroom
        }
        if segue.identifier == writeSegueIdentifier,
           let destination = segue.destination as? reviewWriteVC {
            destination.bathroom = self.bathroom
        }
    }
}

