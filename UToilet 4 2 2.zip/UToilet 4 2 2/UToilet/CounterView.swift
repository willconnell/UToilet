//
//  CounterView.swift
//  UToilet
//
//  Created by Max Truty on 12/5/21.
//

import UIKit

@IBDesignable class CounterView: UIView {
  private struct Constants {
    static let numberOfGlasses = 8
    static let lineWidth: CGFloat = 5.0
    static let arcWidth: CGFloat = 76
    
    static var halfOfLineWidth: CGFloat {
      return lineWidth / 2
    }
  }
  
  @IBInspectable var counter: Int = 5
  @IBInspectable var outlineColor: UIColor = UIColor.blue
  @IBInspectable var counterColor: UIColor = UIColor.systemPink
  
  override func draw(_ rect: CGRect) {
      // 1
      let center = CGPoint(x: bounds.width / 2, y: bounds.height / 2)

      // 2
      let radius = max(bounds.width, bounds.height)

      // 3
      let startAngle: CGFloat = 3 * .pi / 4
      let endAngle: CGFloat = .pi / 4

      // 4
      let path = UIBezierPath(
        arcCenter: center,
        radius: radius/2 - Constants.arcWidth/2,
        startAngle: startAngle,
        endAngle: endAngle,
        clockwise: true)

      // 5
      path.lineWidth = Constants.arcWidth
      counterColor.setStroke()
      path.stroke()
  }
}

