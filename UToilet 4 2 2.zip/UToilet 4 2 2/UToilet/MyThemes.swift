//
//  MyThemes.swift
//  UToilet
//
//  Created by Max Truty on 12/5/21.
//

import Foundation
import SwiftTheme

private let lastThemeIndexKey = "lastedThemeIndex"
private let lastMapIndexKey = "lastedMapIndex"
private let lastSwitchIndexKey = "lastedSwitchindex"
private let defaults = UserDefaults.standard

enum MyThemes: Int {
    
    case red   = 0
    case yello = 1
    case blue  = 2
    case night = 3
    
    
    // MARK: -
    
    static var current: MyThemes { return MyThemes(rawValue: ThemeManager.currentThemeIndex)! }
    static var before = MyThemes.red
    
    // MARK: - Switch Theme
    
    static func switchTo(theme: MyThemes) {
        before = current
        ThemeManager.setTheme(index: theme.rawValue)
    }
    
    static func switchToNext() {
        var next = ThemeManager.currentThemeIndex + 1
        if next > 2 { next = 0 } // cycle and without Night
        switchTo(theme: MyThemes(rawValue: next)!)
    }
    
    // MARK: - Switch Night
    
    static func switchNight(isToNight: Bool) {
        switchTo(theme: isToNight ? .night : before)
    }
    
    static func isNight() -> Bool {
        return current == .night
    }
    
    // MARK: - Save & Restore
    
    static func restoreLastTheme() {
        debugPrint("saved: \(defaults.integer(forKey: lastThemeIndexKey))")
        switchTo(theme: MyThemes(rawValue: defaults.integer(forKey: lastThemeIndexKey))!)
    }
    
    static func restoreLastMap(){
        myVariables.currentMapIndex = defaults.integer(forKey: lastMapIndexKey) as? Int ?? Int()
        debugPrint(myVariables.currentMapIndex)
    }
    
    static func saveLastTheme() {
        defaults.set(ThemeManager.currentThemeIndex, forKey: lastThemeIndexKey)
    }
    
    static func saveLastSwitch(){
        defaults.set(myVariables.currentSwitchIndex, forKey: lastSwitchIndexKey)

    }
    
    static func saveLastMap() {
        defaults.set(myVariables.currentMapIndex, forKey: lastMapIndexKey)
    }
    
}



