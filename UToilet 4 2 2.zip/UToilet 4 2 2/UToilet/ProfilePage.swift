//
//  profilePage.swift
//  UToilet
//
//  Created by William Connell on 12/5/21.
//

import UIKit
import SwiftUI

class ProfilePage: UIHostingController<MySwiftUIView> {
    override func viewDidLoad() {
        super.viewDidLoad()
        //setup
        
        // Load in background theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
    }
    
    required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder, rootView: MySwiftUIView())
    }
}

struct MySwiftUIView: View {
    
    @State private var isShowPhotoLibrary = false
    @State private var isShowCamera = false
    @State private var image = UIImage(named: "profilePic")!
    
    var body: some View {
        VStack() {
            Image(uiImage: self.image).resizable().aspectRatio( contentMode: .fit).clipShape(Circle()).shadow(radius: 10).padding(40)
            Text("Username").padding(30)
            Text("Select Profile Picture from:").padding(10)
            Button(action: {
                self.isShowPhotoLibrary = true
            }) {
                Text("Photo Library")
            }.padding(10)
            Button(action: {
                self.isShowCamera = true
            }) {
                Text("Camera")
            }.padding(10)
        }.sheet(isPresented: $isShowPhotoLibrary) {
            ImagePicker(sourceType: .photoLibrary, selectedImage: self.$image)
        }.sheet(isPresented: $isShowCamera) {
            ImagePicker(sourceType: .camera, selectedImage: self.$image)
        }
    }
}




struct ProfilePage_Previews:
    PreviewProvider {
        static var previews: some View {
            MySwiftUIView()
        }
    }
