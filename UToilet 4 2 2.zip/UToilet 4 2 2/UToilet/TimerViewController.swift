//
//  TimerViewController.swift
//  UToilet
//
//  Created by William Connell on 12/5/21.
//

import UIKit

class TimerViewController: UIViewController {
    
    let queue = DispatchQueue(label: "myQueue", qos: .userInitiated)
    var timeLeft = 0
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var timerCountdown: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func startTimer(_ sender: Any) {
        timerCountdown.text = "\(String(60 * Int((timeLabel.text?.dropFirst(6).prefix(1))!)!)) seconds"
//        print(60 * Int((timeLabel.text?.dropFirst(6).prefix(1))!)!)
        timeLeft = 60 * Int((timeLabel.text?.dropFirst(6).prefix(1))!)!
        
        queue.async {
            self.runTimer(initialTime: self.timeLeft)
        }
        

        
    }
    
    @IBAction func changeTimer(_ sender: UIStepper) {
        timeLabel.text = "Time: \(String(Int(sender.value))) min"
//        timeLeft = Int(sender.value) * 60
    }
    
    
    // decrement the time label in new thread
    func decrementTime() {
        let mytime = timeLeft

        DispatchQueue.main.async {
            self.timerCountdown.text = "\(String(mytime - 1)) seconds"
        }
    }
    
    
    // start the timer
    func runTimer(initialTime: Int) {
        var mytime = initialTime
        
        while (mytime > 1) {
            mytime -= 1
            timeLeft -= 1
            sleep(1)
            decrementTime()
            print("my time:", mytime)
        }
        
        // alert user when the timer is done
        let alert = UIAlertController(title: "Timer", message: "Time is up!", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
