//
//  reviewWriteVC.swift
//  SheldenNan-PartialUI
//
//  Created by Nan Shelden on 11/29/21.
//

import UIKit
import Firebase
import FirebaseDatabase


class reviewWriteVC: UIViewController, UITextViewDelegate, UITextFieldDelegate {
    
    var bathroom: Bathroom!
    var rating: Double!
    var data: DatabaseReference! = Database.database().reference()
    var refRev: DatabaseReference!

    @IBOutlet weak var titleField: UITextField!
    
    @IBOutlet weak var reviewField: UITextView!
    @IBOutlet weak var writeReviewTitle: UILabel!
    
    @IBOutlet weak var ratingSC: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reviewField.delegate = self
        reviewField!.layer.borderWidth = 1
        reviewField.text = "Write your review here! (Optional)"
        reviewField.textColor = UIColor.lightGray
        
        refRev = data.child("reviews")
        
        rating = 1
        
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        writeReviewTitle.theme_textColor = GlobalPicker.textColor
        }
    
    func textViewDidBeginEditing(_ reviewField: UITextView) {
        if reviewField.textColor == UIColor.lightGray {
            reviewField.text = nil
            reviewField.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ reviewField: UITextView) {
        if reviewField.text.isEmpty {
            reviewField.text = "Write your review here! (Optional)"
            reviewField.textColor = UIColor.lightGray
        }
    }
    
    @IBAction func onSegmentChanged(_ sender: Any) {
        switch ratingSC.selectedSegmentIndex {
        case 0:
            rating = 1
        case 1:
            rating = 2
        case 2:
            rating = 3
        case 3:
            rating = 4
        case 4:
            rating = 5
        default:
            rating = 5
            print("This should never happen")
        }
        
    }
    
    @IBAction func submitReview(_ sender: Any) {
        
        //generating a new key inside reviews node
        //and also getting the generated key
        let key = refRev.childByAutoId().key
        
        //creating artist with the given values
        let review = ["id":key,
                      "author": Auth.auth().currentUser!.email,
                      "building": bathroom.building.id as String,
                      "rating": rating,
                      "room": bathroom.room,
                      "text": reviewField.text!,
                      "title": titleField.text!
        ] as [String : Any]
    
        //adding the review inside the generated unique key
        refRev.child(key!).setValue(review)
        
        
        
        //save contents to review list of current bathroom
        let review1 = Review()
        review1.title = titleField.text
        review1.text = reviewField.text
        review1.rating = rating
        
        bathroom.reviews.append(review1)
    }

}

