//
//  LoginViewController.swift
//  UToilet
//
//  Created by William Connell on 11/30/21.
//

import UIKit
import Firebase
import FirebaseDatabase

// TODO: change this
// (probably move inside) to work with settings stuff
let ut = true
let vertical = true

class LoginViewController: UIViewController {

    // color settings - chose a scheme
    let background = ut ? UIColor(named: "BurntOrange") : UIColor.white
    let accent = ut ? UIColor.white : UIColor(named: "BurntOrange")
    
    // queue for doing database things
    let dataqueue = DispatchQueue(label: "data", qos: .default)
    
    // define UI elements to appear
    var buttons: UIStackView!
    
    var logInButton: UIButton!
    var signUpButton: UIButton!
    
    var data: DatabaseReference! = Database.database().reference()
    
    var reviews: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //reviews = data.child("reviews/").getData().value as? String ?? "Uknown"
        Auth.auth().addStateDidChangeListener() {
            auth, user in
            if user != nil {
                self.performSegue(withIdentifier: "showHome", sender: nil)
            }
        }
        
        // set the background color
        self.view.backgroundColor = background
        
        // login button
        logInButton = UIButton(type: .roundedRect)
        logInButton.frame = CGRect(x: 0, y: 0, width: 80, height: 25)
        formatButton(logInButton)
        logInButton.setTitle("Log In", for: .normal)
        logInButton.addTarget(self, action: #selector(logIn), for: .touchUpInside)
        
        // signup button
        signUpButton = UIButton(type: .roundedRect)
        signUpButton.frame = CGRect(x: 0, y: 0, width: 80, height: 25)
        formatButton(signUpButton)
        signUpButton.setTitle("Sign Up", for: .normal)
        signUpButton.addTarget(self, action: #selector(signUp), for: .touchUpInside)
        
        // make a stack view for the buttons
        buttons = UIStackView(arrangedSubviews: [logInButton, signUpButton])
        buttons.isLayoutMarginsRelativeArrangement = true
        buttons.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0)
        formatStack(buttons)
        buttons.distribution = .fillEqually
        buttons.setCustomSpacing(5, after: self.logInButton)
        self.view.addSubview(buttons)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        formatButton(logInButton)
        formatButton(signUpButton)
        formatStack(buttons)
    }
    
    // function to do the formating for buttons
    func formatButton(_ button: UIButton) {
        button.backgroundColor = background
        button.layer.cornerRadius = 10
        button.layer.borderWidth = 2
        button.layer.borderColor = accent?.cgColor
        button.setTitleColor(accent, for: .normal)
    }
    
    // function to do the formatting for the stack of buttons
    func formatStack(_ stack: UIStackView){
        if vertical {
            stack.axis = .vertical
            stack.frame = CGRect(x: 0, y: 0, width: 80, height: 55)
        } else {
            stack.axis = .horizontal
            stack.frame = CGRect(x: 0, y: 0, width: 165, height: 25)
        }
        stack.center.x = self.view.center.x
        stack.center.y = self.view.center.y
    }
    
    // action for trying to login in
    @objc func logIn(_ sender:UIButton!) {
        // create the alert to get the login information
        let logInAlert = UIAlertController(
            title: "Log In",
            message: "Enter your email and password",
            preferredStyle: .alert)
        
        // add the necessary text fields
        logInAlert.addTextField(configurationHandler: {
            (email:UITextField!) in email.placeholder = "Email"
        })
        logInAlert.addTextField(configurationHandler: {
            (password:UITextField!) in password.placeholder = "Password"
        })
        
        // add the buttons to confirm or cancel
        logInAlert.addAction(UIAlertAction(
                                title: "Log In",
                                style: .default,
                                handler: {
                                    _ in
                                    if let textFields = logInAlert.textFields,
                                       textFields.count == 2 {
                                        let em = textFields[0].text!
                                        let pass = textFields[1].text!
                                        var present = true
                                        
                                        if em.count == 0 {
                                            // email field is empty
                                            logInAlert.message = "Please enter an email"
                                            textFields[1].text = ""
                                        } else if pass.count == 0 {
                                            // password field is empty
                                            logInAlert.message = "Please enter a password"
                                        } else {
                                            present = false
                                            // both fields are populated
                                            Auth.auth().signIn(withEmail: em, password: pass) {
                                                user, error in
                                                if let error = error {
                                                    logInAlert.message = error.localizedDescription
                                                    self.present(logInAlert, animated: true, completion: nil)
                                                } else {
                                                    let usr = Auth.auth().currentUser?.uid
                                                    self.dataqueue.async {
                                                        self.data.child("/users/\(usr)").getData() {
                                                            error, snapshot in
                                                            guard error == nil else {
                                                                print(error!.localizedDescription)
                                                                return
                                                            }
                                                            //print(snapshot.value!)
                                                            //print(snapshot.value == )
                                                            if !(snapshot.exists()) {
                                                                let new = ["private": false, "reviews": NSArray()] as [String : Any]
                                                                self.data.updateChildValues(["/users/\(usr!)" : new])
                                                            }
                                                            //print(snapshot.value)
                                                            //print(usr)
                                                        }
                                                    }
                                                    self.performSegue(withIdentifier: "showHome", sender: nil)
                                                }
                                            }
                                        }
                                        //print(present)
                                        // if there was an error
                                        if present {
                                            print("weird")
                                            self.present(logInAlert,
                                                         animated: true,
                                                         completion: nil)
                                        }
                                    }
                                }))
        
        logInAlert.addAction(UIAlertAction(
                                title: "cancel",
                                style: .cancel,
                                handler: nil))
        
        self.present(logInAlert, animated: true, completion: nil)
    }
    
    // action for trying to sign up
    @objc func signUp(_sender:UIButton!) {
        // create the alert to get the signup information
        let signUpAlert = UIAlertController(
            title: "Sign Up",
            message: "Enter an email and password",
            preferredStyle: .alert)
        
        // add the necessary text fields
        signUpAlert.addTextField(configurationHandler: {
            (email:UITextField!) in email.placeholder = "Email"
        })
        signUpAlert.addTextField(configurationHandler: {
            (password:UITextField!) in password.placeholder = "Password"
        })
        signUpAlert.addTextField(configurationHandler: {
            (confirm:UITextField!) in confirm.placeholder = "Confirm Password"
        })
        
        // add the buttons to confirm or cancel
        signUpAlert.addAction(UIAlertAction(
                                title: "Sign Up",
                                style: .default,
                                handler: {
                                    _ in
                                    if let textFields = signUpAlert.textFields, textFields.count == 3 {
                                        // get the input for each text field
                                        let em = textFields[0].text!
                                        let pass = textFields[1].text!
                                        let conf = textFields[2].text!
                                        var present = true
                                        
                                        // do all the test
                                        if em.count == 0 {
                                            // email is empty
                                            signUpAlert.message = "Please enter an email"
                                            textFields[1].text! = ""
                                            textFields[2].text! = ""
                                        } else if pass.count == 0 {
                                            // password is empty
                                            signUpAlert.message = "Please enter a password"
                                            textFields[2].text! = ""
                                        } else if conf.count == 0 {
                                            // confirm is empty
                                            signUpAlert.message = "Please confirm password"
                                            textFields[1].text! = ""
                                        } else if pass != conf {
                                            // confirm and password do not match
                                            signUpAlert.message = "Passwords do not match"
                                            textFields[1].text! = ""
                                            textFields[2].text! = ""
                                        } else {
                                            present = false
                                            // all fields populated, passwords match
                                            Auth.auth().createUser(withEmail: em, password: pass) {
                                                user, error in
                                                if let error = error{
                                                    signUpAlert.message = error.localizedDescription
                                                    self.present(signUpAlert, animated: true, completion: nil)
                                                    //print(error.localizedDescription)
                                                } else {
                                                    Auth.auth().signIn(withEmail: em, password: pass) { user,error  in
                                                        let usr = Auth.auth().currentUser?.uid
                                                        self.dataqueue.async {
                                                             self.data.child("/users/\(usr)").getData() {
                                                                error, snapshot in
                                                                guard error == nil else {
                                                                    print(error!.localizedDescription)
                                                                    return
                                                                }
                                                                 if !(snapshot.exists()) {
                                                                     let new = ["private": false, "reviews": NSArray()] as [String : Any]
                                                                     self.data.updateChildValues(["/users/\(usr!)" : new])
                                                                 }
                                                            }
                                                        }
                                                        self.performSegue(withIdentifier: "showHome", sender: nil)
                                                    }
                                                }
                                            }
                                        }
                                        
                                        // if there was an error
                                        if present {
                                            self.present(signUpAlert,
                                                         animated: true,
                                                         completion: nil)
                                        }
                                    }
                                }))
        
        signUpAlert.addAction(UIAlertAction(
                                title: "cancel",
                                style: .cancel,
                                handler: nil))
        
        // present the view
        present(signUpAlert, animated: true, completion: nil)
    }
}
