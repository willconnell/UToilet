//
//  WelcomeViewController.swift
//  UToilet
//
//  Created by Max Truty on 12/5/21.
//

import UIKit
import AVFoundation


class WelcomeViewController: UIViewController {

    var player: AVAudioPlayer?
    var musicBool = true

    @IBOutlet weak var welcomeLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Load in background theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        welcomeLabel.theme_textColor = GlobalPicker.textColor
        debugPrint(myVariables.switchOn)
        
        // play audio
        if musicBool == true {
            if let player = player, player.isPlaying {
                // stop playback
                
                player.stop()
            } else {
                // set up player, and play
                let urlString = Bundle.main.path(forResource: "audio", ofType: "mp3")
                do {
                    try AVAudioSession.sharedInstance().setMode(.default)
                    try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
                    
                    guard let urlString = urlString else {
                        return
                    }
                    
                    player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: urlString))
                    
                    guard let player = player else {
                        return
                    }
                    
                    player.play()
                } catch {
                    print("something went wrong")
                }
            }
        } else if myVariables.switchOn == false {
            player?.stop()
            
        }

    }
    
}

