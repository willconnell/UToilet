//
//  StarHeartButton.swift
//  UToilet
//
//  Created by Max Truty on 12/6/21.
//

import UIKit

extension UIBezierPath {
    convenience init(heartIn rect: CGRect) {
        self.init()

        //Calculate Radius of Arcs using Pythagoras
        let sideOne = rect.width * 0.4
        let sideTwo = rect.height * 0.3
        let arcRadius = sqrt(sideOne*sideOne + sideTwo*sideTwo)/2

        //Left Hand Curve
        self.addArc(withCenter: CGPoint(x: rect.width * 0.3, y: rect.height * 0.35), radius: arcRadius, startAngle: 135.degreesToRadians, endAngle: 315.degreesToRadians, clockwise: true)

        //Top Centre Dip
        self.addLine(to: CGPoint(x: rect.width/2, y: rect.height * 0.2))

        //Right Hand Curve
        self.addArc(withCenter: CGPoint(x: rect.width * 0.7, y: rect.height * 0.35), radius: arcRadius, startAngle: 225.degreesToRadians, endAngle: 45.degreesToRadians, clockwise: true)

        //Right Bottom Line
        self.addLine(to: CGPoint(x: rect.width * 0.5, y: rect.height * 0.95))

        //Left Bottom Line
        self.close()
    }
}

extension Int {
    var degreesToRadians: CGFloat { return CGFloat(self) * .pi / 180 }
}

class HeartView: UIView {
    
    let numberOfEdges = 5
    let fillColor: UIColor = .systemRed
    let strokeColor: UIColor = .systemRed
    let lineWidth: CGFloat = 2
    let innerRadiusRatio: CGFloat = 0.5
    let outerRadius:  CGFloat = 30
    
    @IBInspectable var filled: Bool = true
    @IBInspectable var strokeWidth: CGFloat = 2.0

    override func draw(_ rect: CGRect) {
        
        // draw heart
        if !myVariables.switchOn {
            let bezierPath = UIBezierPath(heartIn: self.bounds)

            if self.strokeColor != nil {
                self.strokeColor.setStroke()
            } else {
                self.tintColor.setStroke()
            }

            bezierPath.lineWidth = self.strokeWidth
            bezierPath.stroke()

            if self.filled {
                self.tintColor.setFill()
                bezierPath.fill()
            }
            
        // draw star
        } else {
            guard let context = UIGraphicsGetCurrentContext() else { return }
            //Draw your stuff in here...
            
            let origin = CGPoint(x: rect.width / 2, y: rect.height / 2)
            let angle = 360 / numberOfEdges
            let lines = (0..<numberOfEdges * 2).map { (index) -> CGPoint in
                var point = origin
                let radius = index % 2 == 0 ? outerRadius : (outerRadius * innerRadiusRatio)
                let pointRotation = index % 2 == 0 ? CGFloat(angle * index) : CGFloat(angle * index) + CGFloat(angle / 2)
                
                point.y -= radius
                point = point.rotate(around: origin, with: pointRotation)
                
                return point
            }
            context.addLines(between: lines)
            context.setStrokeColor(strokeColor.cgColor)
            context.setFillColor(fillColor.cgColor)
            context.setLineWidth(lineWidth)
            context.fillPath()
        }
        

    }

}

