//
//  MapViewController.swift
//  UToilet
//
//  Created by William Connell on 11/17/21.
//

import UIKit
import MapKit
import Firebase
import FirebaseDatabase

class MapViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    // load in from firebase
    var filteredBathrooms: [Bathroom] = []
    var bathrooms: [Bathroom] = []
    var buildings: [Building] = []
    
    var data: DatabaseReference! = Database.database().reference()
    var refLoc: DatabaseReference!
    var refRev: DatabaseReference!
    
    let dataqueue = DispatchQueue(label: "data", qos: .default)
    

    
    // ref
    var ispcl = true
    
    
    
    
    
    
    
    
    
    
    
    
    let gatesDellCoordinates = CLLocationCoordinate2D(latitude: 30.286236, longitude: -97.736515)
    let pclCoordinates = CLLocationCoordinate2D(latitude: 30.282677, longitude: -97.738121)

    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.setRegion(MKCoordinateRegion(center: gatesDellCoordinates, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)), animated: false)
        
        mapView.delegate = self
        addPins()
        
        // Load in background theme
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        
        
        
        
        
        // load in data from firebase
        
    
        //locations
        refLoc = data.child("locations")
        
        //observing the data changes
        refLoc.observe(DataEventType.value, with: { (snapshot) in
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //clearing the list
                self.buildings.removeAll()
                
                //iterating through all the values
                for buildings in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let buildingObj = buildings.value as? [String: AnyObject]
                    let buildingId = buildings.key
                    let buildingName  = buildingObj?["display"]
                    let buildingLat = buildingObj?["latitude"]
                    let buildingLon = buildingObj?["longitude"]
                    let buildingBathrooms = buildingObj?["bathrooms"] as! NSDictionary
                    
                    //creating building object with model and fetched values
                    let building = Building()
                    building.title = buildingName as! String?
                    building.coordinates = CLLocation(latitude: buildingLat as! Double, longitude: buildingLon as! Double)
                    building.id = buildingId
                    
                    //appending it to list
                    self.buildings.append(building)
    
                    for room in buildingBathrooms {
                        let bathroom = Bathroom()
                        bathroom.building = building as Building?
                        bathroom.room = room.key as! String?
                        bathroom.reviews = []
                        self.bathrooms.append(bathroom)
                    }
                }
                self.filteredBathrooms = self.bathrooms
            }
        })
        
        //reviews
        refRev = data.child("reviews")
        
        //observing the data changes
        refRev.observeSingleEvent(of: DataEventType.value, with: { (snapshot) in
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //iterating through all the values
                for reviews in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let reviewObj = reviews.value as? [String: AnyObject]
                    let reviewTitle  = reviewObj?["title"]
                    let reviewText = reviewObj?["text"]
                    let reviewRating = reviewObj?["rating"]
                    let reviewAuthor = reviewObj?["author"]
                    let reviewRoom = reviewObj?["room"]
                    let reviewBuilding = reviewObj?["building"]
                    
                    //creating review object with model and fetched values
                    let review = Review()
                    review.title = reviewTitle as! String?
                    review.text = reviewText as! String?
                    review.rating = reviewRating as! Double?
                    review.author = reviewAuthor as! String?
                
    
                    for bathroom in self.bathrooms {
                        //bathroom.reviews = []
                        if bathroom.building.id == reviewBuilding as! String? && bathroom.room == reviewRoom as! String? {
                            bathroom.reviews.append(review)
                            
                        }
                    }
                }
//                self.tableView.reloadData()
            }
        })
    }
    
    
    // Add all pins to the map
    // In order to scale, this function could iterate through database values, fetching the title and coordinates of each building
    private func addPins() {
        let pinOne = MKPointAnnotation()
        pinOne.coordinate = gatesDellCoordinates
        pinOne.title = "Gates Dell Complex"
        pinOne.subtitle = "Click to Explore Toilets"
        
        let pinTwo = MKPointAnnotation()
        pinTwo.coordinate = pclCoordinates
        pinTwo.title = "Perry Castañedas Library"
        pinTwo.subtitle = "Click to Explore Toilets"
        
        mapView.addAnnotation(pinOne)
        mapView.addAnnotation(pinTwo)
    }
    
    
    // Set up mapView with annotations
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard !(annotation is MKUserLocation) else {
            return nil
        }
        
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "custom")
        
        if annotationView == nil {
            // Create the view
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "custom")
            annotationView?.canShowCallout = true
            // include button
            let rightButton = UIButton(type: .detailDisclosure)
            annotationView?.rightCalloutAccessoryView = rightButton
        } else {
            annotationView?.annotation = annotation
        }
        
        annotationView?.image = UIImage(named: myVariables.imageString)
        
        return annotationView
    }
    
    
    // triggered when i info button pressed
    func mapView(_ mapView: MKMapView,
           annotationView view: MKAnnotationView,
                          calloutAccessoryControlTapped control: UIControl) {
        print("more info pressed")
        
        print(view.annotation?.title!!)
        
        if view.annotation?.title == "Gates Dell Complex" {
            print("the GDC id is 1")
            ispcl = true
        } else if view.annotation?.title == "Perry Castañedas Library" {
            print("the PCL id is 2")
            ispcl = false
        }
        
        performSegue(withIdentifier: "showBuilding", sender: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showBuilding" {
            
            if ispcl {
                let destination = segue.destination as? BathroomVC
                destination?.bathroom = filteredBathrooms[0]
            } else {
                let destination = segue.destination as? BathroomVC
                destination?.bathroom = filteredBathrooms[1]
            }
        }
           
//           let bathroomIndex = tableView.indexPathForSelectedRow?.row {
//            destination.bathroom = filteredBathrooms[bathroomIndex]
//    }


}
}
