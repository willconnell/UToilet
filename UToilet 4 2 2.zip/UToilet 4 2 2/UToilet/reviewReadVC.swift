//
//  reviewReadVC.swift
//  SheldenNan-PartialUI
//
//  Created by Nan Shelden on 11/29/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class reviewReadVC: UIViewController {
    
    var review: Review!
    var data: DatabaseReference! = Database.database().reference()
    var refRev: DatabaseReference!
    var bathroom: Bathroom!
    
    //view objects
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var reviewLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    
    @IBOutlet weak var deleteButton: UIButton!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = review.title!
        ratingLabel.text = "Rating: \(review.rating!)/5"
        reviewLabel.numberOfLines = 0
        reviewLabel.text = review.text!
        
        if review.author == Auth.auth().currentUser!.email {
            
            deleteButton.isHidden = false
        }
        else {
        deleteButton.isHidden = true
        }
        
        refRev = data.child("reviews")
        
        view.theme_backgroundColor = GlobalPicker.backgroundColor
        titleLabel.theme_textColor = GlobalPicker.textColor
        reviewLabel.theme_textColor = GlobalPicker.textColor
        ratingLabel.theme_textColor = GlobalPicker.textColor
    
    }
    
    @IBAction func deleteReview(_ sender: Any) {
        
        refRev.child(review.id).setValue(nil)
        
        // remove from reviews list
        
        if let index = bathroom.reviews.firstIndex(of: review) {
            bathroom.reviews.remove(at: index)
        }
    }
    
}

