//
//  reviewReadVC.swift
//  SheldenNan-PartialUI
//
//  Created by Nan Shelden on 11/29/21.
//

import UIKit

class reviewReadVC: UIViewController {
    
    var review: Review!
    
    //view objects
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var reviewLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    
    @IBOutlet weak var numLikesLabel: UILabel!
    
    @IBOutlet weak var numDislikesLabel: UILabel!
    @IBAction func likePressed(_ sender: Any) {
        review.likes += 1
    }
    
    @IBAction func dislikePressed(_ sender: Any) {
        review.dislikes += 1
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = review.title!
        ratingLabel.text = "Rating: \(review.rating!)/5"
        reviewLabel.numberOfLines = 0
        reviewLabel.text = review.text!
        numLikesLabel.text = "\(review.likes)"
        numDislikesLabel.text = "\(review.dislikes)"
    
    }
    
}

