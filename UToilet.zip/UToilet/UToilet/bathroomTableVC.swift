
//
//  bathroomTableVC.swift
//  SheldenNan-PartialUI
//
//  Created by Nan Shelden on 11/29/21.
//

import UIKit
import MapKit

class Building: Equatable {
    var title: String!
    var coordinates: CLLocation!
    
    static func == (lhs: Building, rhs: Building) -> Bool {
        return lhs.coordinates.coordinate.latitude == rhs.coordinates.coordinate.latitude && lhs.coordinates.coordinate.longitude == rhs.coordinates.coordinate.longitude
    }
    
}

class Review {
    var title: String!
    var text: String!
    var images: [CGImage]!
    var rating: Int!
    var likes: Int = 0
    var dislikes: Int = 0
}

class Bathroom: Equatable {
    
    var bathID: Int!
    var building: Building!
    var level: String!
    var room: String!
    var reviews: [Review] = []
    
    
    var images: [CGImage]!
    
    func show() -> String {
        return "\(building.title!) | Room \(room!)"
    }
    
    static func == (lhs: Bathroom, rhs: Bathroom) -> Bool {
        return lhs.show() == rhs.show()
    }
    
}

class bathroomTableVC: UIViewController,
                       UITableViewDataSource,
                       UITableViewDelegate {
    
    //data holders
    var bathrooms: [Bathroom] = []
    var buildings: [Building] = []
    
    var mapView = MKMapView()
    

    //search bar implementation
    let searchController = UISearchController(searchResultsController: nil)
    var isSearchBarEmpty: Bool {
      return searchController.searchBar.text?.isEmpty ?? true
    }
    var isFiltering: Bool {
      return searchController.isActive && !isSearchBarEmpty
    }
    var filteredBathrooms: [Bathroom] = []
    

    //identifiers
    var textCellIdentifier = "TextCell"
    var bathroomSegueIdentifier = "BathroomSegue"
    
    //view objects
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
        //search bar stuff
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Bathrooms"
        navigationItem.searchController = searchController
        definesPresentationContext = true

        
        //example buildings
        let pcl = Building()
        pcl.title = "Perry-Castaneda Library"
        pcl.coordinates = CLLocation(latitude:30.282677,longitude:-97.738121)
        let dellGates = Building()
        dellGates.title = "Dell-Gates Building"
        dellGates.coordinates = CLLocation(latitude:30.28236,longitude:-97.736515)
        
        self.buildings.append(pcl)
        self.buildings.append(dellGates)
        
        //example bathrooms
        let br_000 = Bathroom()
        br_000.building = pcl
        br_000.level = "1"
        br_000.room = "1.250"
        br_000.bathID = 1
        
        let br_001 = Bathroom()
        br_001.building = dellGates
        br_001.level = "3"
        br_001.room = "3.046"
        br_001.bathID = 2
        
        self.bathrooms.append(br_000)
        self.bathrooms.append(br_001)
        
        //example reviews
        let r_0 = Review()
        r_0.title = "My favorite bathroom on campus..."
        r_0.text = "This bathroom is so clean and big! It's never crowded and ive never had problems with it. also pretty good location. one star off though for making me walk up stairs to poop lol"
        r_0.rating = 4
        
        let r_1 = Review()
        r_1.title = "So disgusting"
        r_1.text = "it smells so bad and its so far from everything. literally almost peed myself and threw up. i wish i could give 0 stars."
        r_1.rating = 1
        
        br_000.reviews.append(r_0)
        br_001.reviews.append(r_1)
        
    }
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
      if isFiltering {
        return filteredBathrooms.count
      }
        
      return bathrooms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let bathroom: Bathroom
        
        if isFiltering {
            bathroom = filteredBathrooms[indexPath.row]
        }
        else {
            bathroom = bathrooms[indexPath.row]
        }
        cell.textLabel?.numberOfLines = 0
        let userLocation = mapView.userLocation.location
        cell.textLabel?.text = "Building: \(bathrooms[indexPath.row].building.title!)\n Room #: \(bathrooms[indexPath.row].room!)\n" //Distance: \(userLocation!.distance(from: bathrooms[indexPath.row].building.coordinates)) meters"
      return cell
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == bathroomSegueIdentifier,
           let destination = segue.destination as? BathroomVC,
           let bathroomIndex = tableView.indexPathForSelectedRow?.row {
            destination.bathroom = bathrooms[bathroomIndex]
        }
    }
    
    func filterContentForSearchText(_ searchText: String,
                                    category: Bathroom? = nil) {
      filteredBathrooms = bathrooms.filter { (bathroom: Bathroom) -> Bool in
          return bathroom.building.title.lowercased().contains(searchText.lowercased())
      }
      
      tableView.reloadData()
    }

}

extension bathroomTableVC: UISearchResultsUpdating {
  func updateSearchResults(for searchController: UISearchController) {
      let searchBar = searchController.searchBar
      filterContentForSearchText(searchBar.text!)

  }
}
