//
//  reviewWriteVC.swift
//  SheldenNan-PartialUI
//
//  Created by Nan Shelden on 11/29/21.
//

import UIKit

class reviewWriteVC: UIViewController {
    
    var bathroom: Bathroom!
    //var title: String!
    var rating: Int!
    //var
    @IBOutlet weak var titleField: UITextField!
    
    @IBOutlet weak var reviewTextField: UITextField!
    @IBOutlet weak var ratingSC: UISegmentedControl!
    
    @IBAction func onSegmentChanged(_ sender: Any) {
        switch ratingSC.selectedSegmentIndex {
        case 0:
            rating = 1
        case 1:
            rating = 2
        case 2:
            rating = 3
        case 3:
            rating = 4
        case 4:
            rating = 5
        default:
            rating = 5
            print("This should never happen")
        }
        
    }
    
    @IBAction func submitReview(_ sender: Any) {
        
        //save contents to review list of current bathroom
        let review = Review()
        review.title = titleField.text
        review.text = reviewTextField.text
        review.rating = rating
        
        bathroom.reviews.append(review)
    }
    
    
    

}

